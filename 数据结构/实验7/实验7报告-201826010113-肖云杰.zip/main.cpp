#include <iostream>
#include "Graphm.h"
using namespace std;
int min(int a,int b)
{
	if(a<=b) return a;
	else return b;
}
int main(int argc, char** argv) {
	int n,m;
	cin >>n>>m;
	Graphm x(n);
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			x.setEdge(i,j,99999); 
		}
	}
	for(int i=0;i<m;i++)
	{
		int t,a,b,c;
		cin >>t>>a>>b>>c;
		if(t==0)
		{
			int min_num=min(x.matrix[a-1][b-1],c);
			x.setEdge(a-1,b-1,min_num); 
			x.setEdge(b-1,a-1,min_num); 
		}
		else if(t==1)
		{
			c=c*c;
			int min_num=min(x.matrix[a-1][b-1],c);
			x.setEdge(a-1,b-1,min_num); 
			x.setEdge(b-1,a-1,min_num); 
		}
	}
    for (int k=0; k<n; k++) {
        for (int i=0; i<n; i++) {
            for (int j=0; j<n; j++) {
                if (i == j) {
                    continue;
                }
                if (x.matrix[i][k]!=-1 && x.matrix[k][j]!=-1) {
                	int min_num=min(x.matrix[i][j], x.matrix[i][k]+x.matrix[k][j]);
                    x.setEdge(i,j,min_num);
                }
            }
        }
    }
   	cout << x.matrix[0][n-1];
	return 0;
}
