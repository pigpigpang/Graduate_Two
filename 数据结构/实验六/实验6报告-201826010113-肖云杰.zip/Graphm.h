#include "Graph.h"
class Graphm : public Graph{
	public:
		int numVertex,numEdge;
		int **matrix;
		int flag[21][21];
		int *mark;
	public:
		Graphm (int numVert) {
		Init(numVert);
		for(int i=0;i<21;i++)
			for(int j=0;j<21;j++)
				flag[i][j]=0;
		};
		~Graphm(){
			delete [] mark;
			for(int i=0;i<numVertex;i++)
				delete []matrix[i];
			delete []matrix;
		}
		void Init(int n){
			int i;
			numVertex=n;
			numEdge=0;
			mark=new int[n];
			for(i=0 ;i<numVertex;i++)
				mark[i]=0;
			matrix=(int **) new int*[numVertex];
			for(i=0;i<numVertex;i++)
				matrix[i]=new int[numVertex];
			for(i=0;i<numVertex;i++)
				for(int j=0;j<numVertex;j++)
					matrix[i][j]=0;
		}
		int n(){return numVertex;}
		int e(){return numEdge;}
		int first(int v){
			for(int i=0;i<numVertex;i++)
				if(matrix[v][i]!=0) return i;
			return numVertex;
		}
		int next(int v,int w){
			for(int i=w+1;i<numVertex;i++)
				if(matrix[v][i]!=0) return i;
			return numVertex;
		} 
		void setEdge(int v1,int v2,int wt){
			assert(wt>0);
			if(matrix[v1][v2]==0) numEdge++;
			matrix[v1][v2]=wt;
		}
		void delEdge(int v1,int v2){
			if(matrix[v1][v2]!=0) numEdge--;
			matrix[v1][v2]=0;
		}
		bool isEdge(int i,int j){
			return matrix[i][j]!=0;
		}
		int weight(int v1,int v2){
			return matrix[v1][v2];
		}
		int getMark(int v){
			return mark[v];
		}
		void setMark(int v,int val){
			mark[v]=val;
		}
		void clearmark()
		{
			for(int i=0;i<numVertex;i++)
				mark[i]=0;
		}
		void dfs(int v1,int v2)
		{
			int w;
			setMark( v1,1);
			flag[v1][v2]=1;
			flag[v2][v1]=1;
			for(w=first(v1);w<n();w=next(v1,w))
			{
				if(getMark(w)==0)
				dfs(w,v2);
			}
		}
		int ans()
		{
			int ans=0,j=0;
			for(int i=0;i<numVertex;i++)
			{
				for( j=0;j<numVertex&&flag[i][j]==1;j++)
				{
					
				}
				if(j==numVertex)ans++;
			}
			return ans;
		}
};
