#include <iostream>
#include "Graphm.h"
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
using namespace std;
int main(int argc, char** argv) {
	int n,m;
	cin >> n>>m;
	Graphm a(n);
	for(int i=0;i<m;i++)
	{
		int x,y;
		cin >> x>> y;
		a.setEdge(x-1,y-1,1); 
	}
	for(int i=0;i<n;i++)
	{
		a.dfs(i,i);
		a.clearmark();	
	}
	cout<<a.ans();
	return 0;
}
