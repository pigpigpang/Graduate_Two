#include <iostream>
#include <string>
#include "link.h"
using namespace std;
int main(int argc, char** argv) {
	LList<char> a;
	string in;
	cin >> in;
	int letter=0,sum=0,other=0;
	int len=in.length();
	for(int i=0;i<len;i++)
	{
		a.append(in[i]);
	}
	letter=a.count_letter();
	sum=a.count_num();
	other=a.count_other();
	cout << letter << ' '<<sum << ' '<<other<<endl;
	a.delete_num();
	a.print();
	return 0;
}
